-- Niger Marché : schéma initial Supabase (PostgreSQL)
-- À exécuter dans SQL Editor d'un projet Supabase après création du projet.
create extension if not exists pgcrypto;

create table if not exists public.listings (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  category text not null check (category in ('Parcelles','Maisons','Locations','Hôtels','Voitures','Motos')),
  offer text not null check (offer in ('Vente','Location','Hébergement')),
  city text not null,
  area text,
  price numeric(14,2) not null check (price >= 0),
  period text,
  description text,
  phone text not null,
  photo_url text,
  status text not null default 'pending' check (status in ('pending','published','rejected')),
  created_at timestamptz not null default now()
);

alter table public.listings enable row level security;

-- Visiteurs : uniquement les annonces validées sont lisibles.
create policy "Public can read published listings"
on public.listings for select
using (status = 'published');

-- Dépôt public : les annonces arrivent en attente de validation.
create policy "Anyone can submit pending listings"
on public.listings for insert
with check (status = 'pending');

create index if not exists listings_category_idx on public.listings(category);
create index if not exists listings_city_idx on public.listings(city);
create index if not exists listings_created_idx on public.listings(created_at desc);

-- IMPORTANT : ne jamais placer la clé service_role dans le navigateur.
-- Le contrôle des statuts et la modération doivent se faire dans un espace admin sécurisé.

-- Tables de suivi financier. La confirmation réelle doit être faite par un backend/webhook sécurisé.
create table if not exists public.payment_orders (
 id uuid primary key default gen_random_uuid(),
 payer_phone text not null,
 provider text not null check (provider in ('Airtel Money','Moov Money','Zamani Money','Nita Transfert','Amanata Transfert')),
 purpose text not null check (purpose in ('listing_fee','featured_listing','subscription','commission')),
 amount numeric(14,2) not null check (amount > 0),
 currency text not null default 'XOF',
 status text not null default 'pending' check (status in ('pending','confirmed','failed','refunded')),
 provider_reference text unique,
 created_at timestamptz not null default now()
);
alter table public.payment_orders enable row level security;
-- Pas d'accès public aux paiements : passer par le serveur uniquement.
create table if not exists public.transaction_reports (
 id uuid primary key default gen_random_uuid(),
 listing_ref text not null,
 transaction_type text not null,
 declared_amount numeric(14,2) not null check (declared_amount > 0),
 estimated_fee numeric(14,2) not null default 0,
 contact_phone text not null,
 status text not null default 'pending' check (status in ('pending','verified','disputed','closed')),
 notes text,
 created_at timestamptz not null default now()
);
alter table public.transaction_reports enable row level security;
