-- VISION24 : migration initiale idempotente
-- À exécuter dans Supabase > Éditeur SQL > Nouvelle requête.

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role text not null default 'editor' check (role in ('admin','editor')),
  created_at timestamptz not null default now()
);

create table if not exists public.publications (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  content text,
  media_url text,
  media_type text not null default 'image',
  status text not null default 'draft' check (status in ('draft','published')),
  published_at timestamptz,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);

create table if not exists public.videos (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  video_url text,
  status text not null default 'draft' check (status in ('draft','published')),
  created_at timestamptz not null default now()
);

create table if not exists public.radio_settings (
  id boolean primary key default true check (id = true),
  station_name text not null default 'Radio Vision 24',
  frequency text not null default '95.1 FM',
  stream_url text,
  updated_at timestamptz not null default now()
);
insert into public.radio_settings (id) values (true) on conflict (id) do nothing;

create table if not exists public.live_streams (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  platform text,
  stream_url text,
  status text not null default 'upcoming' check (status in ('upcoming','live','ended')),
  created_at timestamptz not null default now()
);

create or replace function public.is_admin()
returns boolean
language sql
security definer
set search_path = ''
stable
as $$
  select exists (
    select 1 from public.profiles
    where id = (select auth.uid()) and role = 'admin'
  );
$$;
grant execute on function public.is_admin() to authenticated;

alter table public.profiles enable row level security;
alter table public.publications enable row level security;
alter table public.videos enable row level security;
alter table public.radio_settings enable row level security;
alter table public.live_streams enable row level security;

-- Supprime les politiques portant les mêmes noms pour rendre la migration relançable.
drop policy if exists "profile_self_read" on public.profiles;
drop policy if exists "admin_profiles_all" on public.profiles;
drop policy if exists "admin_publications_all" on public.publications;
drop policy if exists "public_published_publications" on public.publications;
drop policy if exists "admin_videos_all" on public.videos;
drop policy if exists "public_published_videos" on public.videos;
drop policy if exists "admin_radio_all" on public.radio_settings;
drop policy if exists "public_radio_read" on public.radio_settings;
drop policy if exists "admin_live_all" on public.live_streams;
drop policy if exists "public_live_read" on public.live_streams;

create policy "profile_self_read" on public.profiles
for select to authenticated using (id = (select auth.uid()));
create policy "admin_profiles_all" on public.profiles
for all to authenticated using (public.is_admin()) with check (public.is_admin());

create policy "admin_publications_all" on public.publications
for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "public_published_publications" on public.publications
for select to anon, authenticated using (status = 'published');

create policy "admin_videos_all" on public.videos
for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "public_published_videos" on public.videos
for select to anon, authenticated using (status = 'published');

create policy "admin_radio_all" on public.radio_settings
for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "public_radio_read" on public.radio_settings
for select to anon, authenticated using (true);

create policy "admin_live_all" on public.live_streams
for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "public_live_read" on public.live_streams
for select to anon, authenticated using (status in ('live','upcoming'));

-- Important : le compte existant doit déjà avoir role='admin' dans profiles.
