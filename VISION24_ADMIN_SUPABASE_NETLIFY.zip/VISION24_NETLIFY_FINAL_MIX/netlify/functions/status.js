exports.handler = async () => ({
  statusCode: 200,
  headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" },
  body: JSON.stringify({
    ok: true,
    platform: "netlify",
    app: "VISION 24 NIGER",
    publishingEnabled: false,
    socialAccountsConnected: false,
    note: "Le serveur répond. Les comptes Facebook, YouTube et WhatsApp ne sont pas connectés automatiquement."
  })
});
