exports.handler = async () => ({
  statusCode: 501,
  headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" },
  body: JSON.stringify({ ok: false, platform: "Facebook", enabled: false,
    message: "Désactivé volontairement : authentification admin, OAuth, stockage sécurisé des jetons et journal d'audit requis." })
});
